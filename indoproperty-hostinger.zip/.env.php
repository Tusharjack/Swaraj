<?php
/**
 * .env.php — Supabase credentials for reel.php (PHP runtime)
 *
 * This file is NOT served publicly — .htaccess blocks direct access to .php
 * files that start with a dot. It is only included by reel.php.
 *
 * Fill in your actual values from Supabase Dashboard → Project Settings → API
 */
putenv('VITE_SUPABASE_URL=https://jueatkomupnzbwovzsle.supabase.co');
putenv('VITE_SUPABASE_PUBLISHABLE_KEY=sb_publishable_WmjT7P6VS1lyv3sPNhyXWA_Z7RcE1zC');
